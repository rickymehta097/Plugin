<?php // Silence is golden.
