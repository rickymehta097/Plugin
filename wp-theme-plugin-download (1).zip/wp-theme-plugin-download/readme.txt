=== Wp Theme plugin Download  ===
Contributors: abhay-raj
Donate link: http://paypal.me/abhayyadav
Tags: theme Download, plugin Download, wordpress Download, clone plugin, clone themes, Download themes, wp Download, wp Downloader, Theme and plugin Download, wp theme plugin Download, Download plugin, Download plugin from dashboard, Download theme from admin.
Requires at least: 3.0
Tested up to: 5.5
Stable tag: 1.4
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

== Description ==
Download plugins and themes on your site as a .zip and ready to install on another site.

= This plugin include these Two plugins =
* Download Themes from wordpress admin panel.
* Download Plugins from wordpress admin panel.

= Features =
* easy to install
* No need to settings in admin.

= Requirements =
This plugin requires PHP 5 or PHP 7 and WordPress 3.0 or greater. It works in standard WordPress environments. It is strongly recommended to use WordPress in the newest version.

= Contact =
* If you have any suggestion, feel free to email me at abhayrajmca@gmail.com or info@inizsoft.com

== Installation ==

1. Go to Plugins > Add New or Download the plugin and unzip it. 
2. Searh "wp theme plugin download" Or Upload the folder to your /wp-content/plugins/ folder.
3. install and activate the WordPress admin panel.


== How to Use ==

only need to activate the plugin.

== Frequently Asked Questions ==

* If you have any suggestion, feel free to email me at abhayrajmca@gmail.com or info@inizsoft.com
* post Question on support forum


== Screenshots ==

1. screenshot-1.jpg
1. screenshot-2.jpg
